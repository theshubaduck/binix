Imports System.IO
Imports System.Reflection

Module BinixFramework
    Private services As New Dictionary(Of String, List(Of String)) From {
        {"File Management", New List(Of String)},
        {"Process Management", New List(Of String)}
    }

    Private modules As New List(Of Type)

    Sub Main()
        Console.WriteLine("Welcome to Binix Framework!")
        InitializeCoreServices()

        Dim command As String
        Do
            Console.Write("binix> ")
            command = Console.ReadLine()
            ProcessCommand(command)
        Loop While command.ToLower() <> "exit"
    End Sub

    Sub InitializeCoreServices()
        services("File Management").Add("Create File")
        services("File Management").Add("Delete File")
        services("File Management").Add("Edit File")
        services("File Management").Add("List Files")
        services("Process Management").Add("Run Process")

        Console.WriteLine("Core services initialized:")
        For Each category In services
            Console.WriteLine($"  {category.Key}:")
            For Each service In category.Value
                Console.WriteLine($"    - {service}")
            Next
        Next
    End Sub

    Sub ProcessCommand(command As String)
        Dim parts() As String = command.Split(" "c)
        Dim cmd As String = parts(0).ToLower()

        Select Case cmd
            Case "exit"
                Console.WriteLine("Exiting Binix Framework.")
            Case "help"
                ShowHelp()
            Case "file"
                HandleFileCommand(parts)
            Case "process"
                HandleProcessCommand(parts)
            Case "addmodule"
                If parts.Length > 1 Then
                    LoadModule(parts(1))
                Else
                    Console.WriteLine("Usage: addmodule <module_name>")
                End If
            Case Else
                Console.WriteLine("Unknown command.")
        End Select
    End Sub

    Sub HandleFileCommand(parts As String())
        If parts.Length < 2 Then
            Console.WriteLine("Usage: file [create/delete/edit/list] <filename>")
            Return
        End If

        Dim action As String = parts(1).ToLower()
        Dim filename As String = If(parts.Length > 2, parts(2), "")

        Select Case action
            Case "create"
                CreateFile(filename)
            Case "delete"
                DeleteFile(filename)
            Case "edit"
                EditFile(filename)
            Case "list"
                ListFiles()
            Case Else
                Console.WriteLine("Unknown file action.")
        End Select
    End Sub

    Sub HandleProcessCommand(parts As String())
        If parts.Length < 2 Then
            Console.WriteLine("Usage: process run <process_name>")
            Return
        End If

        Dim action As String = parts(1).ToLower()
        Dim processName As String = parts(2)

        Select Case action
            Case "run"
                RunProcess(processName)
            Case Else
                Console.WriteLine("Unknown process action.")
        End Select
    End Sub

    Sub ShowHelp()
        Console.WriteLine("Available commands:")
        Console.WriteLine("help - Show this help message")
        Console.WriteLine("exit - Exit Binix Framework")
        Console.WriteLine("file [create/delete/edit/list] <filename> - Manage files")
        Console.WriteLine("process run <process_name> - Simulate running a process")
        Console.WriteLine("addmodule <module_name> - Load a custom module")
    End Sub

    Sub LoadModule(moduleName As String)
        Try
            Dim assembly As Assembly = Assembly.LoadFrom(moduleName & ".dll")
            For Each type In assembly.GetTypes()
                If type.GetInterface("IModule") IsNot Nothing Then
                    modules.Add(type)
                    Console.WriteLine($"Module '{moduleName}' loaded.")
                End If
            Next
        Catch ex As Exception
            Console.WriteLine($"Error loading module: {ex.Message}")
        End Try
    End Sub

    Sub CreateFile(fileName As String)
        Try
            File.Create(fileName).Dispose()
            Console.WriteLine($"File '{fileName}' created.")
        Catch ex As Exception
            Console.WriteLine($"Error creating file: {ex.Message}")
        End Try
    End Sub

    Sub DeleteFile(fileName As String)
        If File.Exists(fileName) Then
            Try
                File.Delete(fileName)
                Console.WriteLine($"File '{fileName}' deleted.")
            Catch ex As Exception
                Console.WriteLine($"Error deleting file: {ex.Message}")
            End Try
        Else
            Console.WriteLine($"File '{fileName}' does not exist.")
        End If
    End Sub

    Sub EditFile(fileName As String)
        If Not File.Exists(fileName) Then
            Console.WriteLine($"File '{fileName}' does not exist.")
            Return
        End If

        Dim lines() As String = File.ReadAllLines(fileName)
        Dim editing As Boolean = True

        While editing
            Console.WriteLine($"Editing file '{fileName}':")
            For i As Integer = 0 To lines.Length - 1
                Console.WriteLine($"{i + 1}: {lines(i)}")
            Next

            Console.Write("Enter line number to edit, 's' to save, or 'q' to quit: ")
            Dim input As String = Console.ReadLine()

            Select Case input.ToLower()
                Case "q"
                    editing = False
                Case "s"
                    File.WriteAllLines(fileName, lines)
                    Console.WriteLine($"Changes saved to '{fileName}'.")
                    editing = False
                Case Else
                    Dim lineNumber As Integer
                    If Integer.TryParse(input, lineNumber) AndAlso lineNumber > 0 AndAlso lineNumber <= lines.Length Then
                        Console.Write($"Enter new content for line {lineNumber}: ")
                        lines(lineNumber - 1) = Console.ReadLine()
                    Else
                        Console.WriteLine("Invalid input. Please enter a valid line number.")
                    End If
            End Select
        End While
    End Sub

    Sub ListFiles()
        Dim files() As String = Directory.GetFiles(".")
        Console.WriteLine("Files in current directory:")
        For Each file In files
            Console.WriteLine(file)
        Next
    End Sub

    Sub RunProcess(processName As String)
        Console.WriteLine($"Simulating running process '{processName}'...")
        For i As Integer = 1 To 5
            Console.WriteLine($"Process '{processName}' running... {i * 20}% complete.")
            System.Threading.Thread.Sleep(1000)
        Next
        Console.WriteLine($"Process '{processName}' completed.")
    End Sub
End Module

' Example interface for modules
Public Interface IModule
    Sub Initialize()
End Interface
